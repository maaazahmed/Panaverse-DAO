"use client";
import React from "react";
import Image from "next/image";
import { FiFacebook, FiGithub ,FiLinkedin ,FiInstagram} from "react-icons/fi";


interface HeroProps {
  heading: string;
  message: string;
}

const Hero = ({ heading, message }: HeroProps) => (
  <div className="flex items-center px-[10rem] h-screen mb-0 bg-fixed bg-cover bg-center custom-img pt-[80px]">
    <div className="absolute top-0 left-0 right-0 bottom-0 bg-black/60 z-[2]" />
    <div className=" w-[70%] text-white z-[2] ">
      <h2 className={"text-[5rem] font-audiowide font-bold uppercase "}>
        In a Nutshell
      </h2>
      <h2
        className={
          "text-[3.4rem] font-audiowide font-bold uppercase text-transparent bg-clip-text bg-gradient-to-r from-[#df072a] to-[#a11328] "
        }
      >
        Earn While You Learn
      </h2>
      {/* <h2 className={"text-[5rem] font-bold"}>Earn While You Learn</h2> */}
      <p className=" text-2xl w-[80%] mt-3 font-ShareTech capitalize">
        In this brand-new type of curriculum, students will learn how to make
        money and boost exports in the classroom and will begin doing so within
        six months of the program's beginning.
      </p>

      <div className="flex justify-center flex-col w-[80%]">
      
        <div className=" h-[80px] bg-[red]/0 w-[50%] flex items-center   font-ShareTech capitalize my-[1rem]">
          <button className="h-[50px] mr-3 justify-center flex items-center w-[50px] backdrop-blur-xl bg-gradient-to-r bg-white/5 border-white/10 border-[1px] rounded ">
            <FiFacebook className="text-3xl" />
          </button>
          <button className="h-[50px] mr-3 justify-center flex items-center w-[50px] backdrop-blur-xl bg-gradient-to-r bg-white/5 border-white/10 border-[1px] rounded ">
            <FiGithub className="text-3xl" />
          </button>
          <button className="h-[50px] mr-3 justify-center flex items-center w-[50px] backdrop-blur-xl bg-gradient-to-r bg-white/5 border-white/10 border-[1px] rounded ">
            <FiLinkedin className="text-3xl" />
          </button>
          <button className="h-[50px] mr-3 justify-center flex items-center w-[50px] backdrop-blur-xl bg-gradient-to-r bg-white/5 border-white/10 border-[1px] rounded ">
            <FiInstagram className="text-3xl" />
          </button>
          {/* rounded backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px]  flex items-center justify-center */}
        </div>
        <button className="px-[0rem] w-[234px] text-2xl py-3 mt-0 border font-ShareTech capitalize rounded ">
          Apply Now
        </button>
        
      </div>
    </div>
    <div
      className={`flex items-center justify-center bg-white/0 h-full  duration-500 flex-1 z-[2] `}
    >
      {/* <div className="h-full w-[40rem] bg-contain bg-no-repeat bg-center bg-[url(https://moralis.io/wp-content/uploads/2023/01/Illustrative-Woman-Interacting-with-Web3-Tech-1024x826.png)]" ></div> */}
      <div className="min-h-[25rem] w-[40rem]  bg-white/0 flex flex-col">
        <div className={"flex w-[32rem] my-2 justify-between self-end "}>
          <div className=" h-[10rem] w-[10rem]" />
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/meta.png")}
              alt=""
            />
          </div>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/bitcoin.png")}
              alt=""
            />
          </div>
        </div>
        <div className={"flex w-[32rem] my-2 justify-between self-end "}>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/user.png")}
              alt=""
            />
          </div>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/nft.png")}
              alt=""
            />
          </div>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/technology.png")}
              alt=""
            />
          </div>
        </div>
        <div className={"flex w-[32rem] my-2 justify-between self-end "}>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/ethereum.png")}
              alt=""
            />
          </div>
          <div className=" h-[10rem] w-[10rem] backdrop-blur-xl bg-gradient-to-r from-[rgba(223,7,43,.0)] to-[rgba(161,19,40,.0)] border-white/10 border-[1px] rounded flex items-center justify-center">
            <Image
              height={80}
              width={80}
              src={require("../assets/icons/cloud.png")}
              alt=""
            />
          </div>
          <div className=" h-[10rem] w-[10rem]" />
        </div>
      </div>
    </div>
  </div>
);

export default Hero;

// TS, NEXTJS NODEJS, Python Solidty AWSCDK html/css
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
// bg-gradient-to-r from-[rgba(223,7,43,1)] to-[rgba(161,19,40,1)]
