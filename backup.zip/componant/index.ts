import Navbar from "./Navbar";
import Hero from "./Hero";
import Penaverse from "./Penaverse";


export  {
    Navbar,
    Hero,
    Penaverse
}
