/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{html,js,jsx}',
    './componant/**/*.{html,js,jsx,tsx}',
    './sections/**/*.{html,js,jsx, tsx}',
    './styles/**/*.{js,jsx, tsx}',
     
  ],
  mode: 'jit',

  theme: {


    fontFamily: {
      'audiowide': ['Audiowide', "cursive"],
      "ShareTech":["Share Tech"]
    },
    extend: {
        colors: {
          "logo-light":"#df072a",
          "logo-dark":"#a11328",
        },
  
     },
  },
  plugins: [],
};


// /** @type {import('tailwindcss').Config} */
// module.exports = {
//   content: [
//     './pages/**/*.{js,ts,jsx,tsx}',
//     './components/**/*.{js,ts,jsx,tsx}',
//   ],
//   theme: {
//     extend: {},
//   },
//   plugins: [],
// };